# 🐐 Bakra Mandi - Eid Livestock Marketplace

A complete, production-ready Eid-themed livestock marketplace website with festive design, full backend, payment processing, and order management.

## ✨ Features

### Frontend
- ✅ Festive Eid aesthetic (gold & green)
- ✅ Responsive design (mobile, tablet, desktop)
- ✅ Livestock listings (goats, cows, sheep)
- ✅ Shopping cart functionality
- ✅ Product filtering
- ✅ Smooth animations

### Backend
- ✅ Express.js REST API
- ✅ MongoDB database
- ✅ Order management system
- ✅ Payment processing (Stripe)
- ✅ Email notifications
- ✅ Contact form
- ✅ SEO optimization

### Security
- ✅ Helmet.js security headers
- ✅ CORS protection
- ✅ Rate limiting
- ✅ Input validation

## 🚀 Quick Start

### Prerequisites
- Node.js 16+
- MongoDB
- npm or yarn

### Installation

1. **Clone repository**
```bash
git clone https://github.com/yourusername/bakra-mandi.git
cd bakra-mandi
```

2. **Install dependencies**
```bash
npm install
```

3. **Create .env file**
```bash
cp .env.example .env
```

4. **Configure environment variables**
Edit `.env` with your credentials:
```env
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/bakra-mandi
STRIPE_SECRET_KEY=sk_test_xxxxx
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
```

5. **Start development server**
```bash
npm run dev
```

6. **Access application**
- Frontend: http://localhost:3000
- API: http://localhost:5000
- API Health: http://localhost:5000/api/health

## 📁 Project Structure

```
bakra-mandi/
├── index.html              # Frontend
├── server.js               # Express API
├── package.json            # Dependencies
├── .env.example            # Config template
├── Procfile                # Deployment config
└── README.md               # Documentation
```

## 🔌 API Endpoints

### Livestock
```
GET    /api/livestock              # Get all livestock
GET    /api/livestock?type=goat    # Filter by type
GET    /api/livestock/:id          # Get single item
POST   /api/livestock              # Add new item (admin)
```

### Orders
```
POST   /api/orders                 # Create order
GET    /api/orders/:id             # Get order details
```

### Payments
```
POST   /api/create-payment-intent  # Create Stripe payment
```

### Contact
```
POST   /api/contact                # Submit contact form
```

### SEO
```
GET    /sitemap.xml                # XML sitemap
GET    /robots.txt                 # Robots file
```

## 🎨 Design System

### Colors
- **Primary Green**: #1a5d3d
- **Gold**: #d4af37
- **Light Green**: #2d8659
- **Cream**: #f5f1e8

### Typography
- **Display**: Playfair Display (serif)
- **Body**: Poppins (sans-serif)

### Aesthetic
- Festive Eid celebration theme
- Islamic geometric patterns
- Gold & green color scheme
- Smooth animations
- Responsive layout

## 💳 Payment Integration

### Stripe Setup
1. Create account at https://stripe.com
2. Get API keys from dashboard
3. Add to .env:
```env
STRIPE_SECRET_KEY=sk_test_xxxxx
```

## 📧 Email Setup

### Gmail (Recommended)
1. Enable 2-factor authentication
2. Generate app password
3. Add to .env:
```env
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
```

## 🌐 Deployment

### Railway (Recommended - 2 minutes)

1. **Push to GitHub**
```bash
git remote add origin https://github.com/YOUR_USERNAME/bakra-mandi.git
git branch -M main
git push -u origin main
```

2. **Deploy on Railway**
- Go to https://railway.app
- Click "New Project"
- Select "Deploy from GitHub"
- Select repository
- Click "Deploy"

3. **Add Environment Variables**
In Railway Dashboard:
- Add all variables from .env.example
- Railway auto-deploys on push

4. **Get Live URL**
- Your app is live at: `https://bakra-mandi-xxxxx.railway.app`

### Heroku (Alternative)

```bash
heroku login
heroku create bakra-mandi
heroku config:set MONGODB_URI=your_uri
git push heroku main
```

### DigitalOcean (Full Control)

```bash
# SSH into server
ssh root@your-droplet-ip

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
apt-get install -y nodejs

# Clone repository
git clone https://github.com/yourusername/bakra-mandi.git
cd bakra-mandi
npm install

# Start with PM2
npm install -g pm2
pm2 start server.js --name "bakra-api"
pm2 startup
pm2 save
```

## 📊 Database Schema

### Livestock Collection
```javascript
{
  name: String,
  type: String (goat|cow|sheep),
  price: Number,
  weight: String,
  age: String,
  description: String,
  seller: String,
  phone: String,
  location: String,
  image: String,
  featured: Boolean,
  available: Boolean,
  createdAt: Date
}
```

### Orders Collection
```javascript
{
  orderNumber: String,
  items: [{
    livestockId: String,
    name: String,
    price: Number,
    quantity: Number
  }],
  totalPrice: Number,
  buyerName: String,
  buyerEmail: String,
  buyerPhone: String,
  deliveryAddress: String,
  status: String (pending|confirmed|delivered),
  paymentStatus: String (unpaid|paid),
  stripePaymentId: String,
  createdAt: Date
}
```

## 🔒 Security Checklist

- [ ] Change all default passwords
- [ ] Set NODE_ENV=production
- [ ] Enable HTTPS/SSL
- [ ] Configure firewall rules
- [ ] Set up database backups
- [ ] Enable rate limiting
- [ ] Configure CORS properly
- [ ] Set up monitoring & alerts
- [ ] Enable logging
- [ ] Test payment gateway
- [ ] Verify email notifications
- [ ] Test on mobile devices
- [ ] Performance optimization

## 📱 Responsive Design

- **Mobile**: 320px and up
- **Tablet**: 768px and up
- **Desktop**: 1024px and up

All components are fully responsive and tested across devices.

## 🆘 Troubleshooting

### MongoDB Connection Error
```
Error: connect ECONNREFUSED
```
**Solution**: Ensure MongoDB is running or check connection string

### Port Already in Use
```bash
lsof -i :5000
kill -9 <PID>
```

### Email Not Sending
- Check SMTP credentials
- Verify sender email
- Check spam folder
- Review email logs

## 📞 Support

- **GitHub Issues**: Report bugs
- **Email**: support@bakramandi.com
- **Phone**: +92 300 1234567

## 📄 License

MIT License - See LICENSE file

## 🌙 Eid Mubarak!

Thank you for using Bakra Mandi. May your Eid be blessed and joyful!

---

**Last Updated**: April 2026
**Version**: 1.0.0
**Status**: Production Ready ✅
